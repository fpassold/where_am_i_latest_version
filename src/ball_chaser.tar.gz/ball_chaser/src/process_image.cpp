#include "ros/ros.h"
#include "ball_chaser/DriveToTarget.h"
#include <sensor_msgs/Image.h>

// Define a global client that can request services
ros::ServiceClient client;

// This function calls the command_robot service to drive the robot in the specified direction
void drive_robot (float lin_x, float ang_z)
{
    // TO dO: Request a service and pass the velocities to it to drive the robot
    ball_chaser::DriveToTarget srv;
    srv.request.linear_x = lin_x;
    srv.request.angular_z = ang_z;
    if (!client.call(srv)){
        ROS_ERROR("[process_image.cpp]: failed to call service DriveToTarget");
    }    
}

// This callback function continuously executes and reads the image data
void process_image_callback(const sensor_msgs::Image img)
{
    int white_pixel = 230;
    int bigger_area = 500;
    float max_linear_vel = 0.3;
    int x=0, y=0;       // estimates centroid ball position
    bool ball_found = false;
    int first_point;    // first identified white pixel
    int last_point;     // last identified white pixel
    bool first_found = false; // identified first white pixel
    bool last_found = false; // identified last white pixel - exit the loop
    int white_area = 0; // counts amount of white pixels
    //  large area = robot close to the ball -> reduce speed
    // small area = distant ball -> increase robot speed
    int not_white = 0;  // counts non-white pixel sequence. stops counting when count >= img.width
    int i, j;           // indexes used to manipulate img.data []
    float v = 0.0;      // linear velocity
    float w = 0.0;      // angular velocity
    unsigned int red_ch, green_ch, blue_ch;

    // TO dO: Loop through each pixel in the image and check if there's a bright white one
    // Loop through each pixel in the image and check if its equal to 255 without any tolerancy

    // first step: finding first point; in this case, first_found = false
    for (i = 0; i < img.height*img.width; i++) { // advances every 3 bytes,
          red_ch=img.data[i*3];
        green_ch=img.data[i*3+1];
         blue_ch=img.data[i*3+2];
        // if (img.data[i] >= white_pixel){
        if ((red_ch>=white_pixel)&&(green_ch>=white_pixel)&&(blue_ch>=white_pixel)){
            ball_found = true;
            first_found = true;
            first_point = i;
            ROS_INFO("[process_image]: first point ball found @ i=%3i", first_point); 
            white_area = 1;
            break;    
        }
    }
    // checking the last pixel of the image and no ball
    // then get out of the routine (there is nothing more to do)
    if (ball_found==true){
        // search img.data from the previous point onwards
        // but it also counts sequential amount of non-white pixels in variable not_white
        // if not_white >= img.width means that the end of the ball has already been found and
        // then we can get out of this second loop
        for (j = i+1;  j < img.height*img.width; j++) {
            // hunting white pixels
              red_ch=img.data[j*3];
            green_ch=img.data[j*3+1];
             blue_ch=img.data[j*3+2];
            // if (img.data[j] >= white_pixel){
            if ((red_ch>=white_pixel)&&(green_ch>=white_pixel)&&(blue_ch>=white_pixel)){
                white_area++; // integrates amount of white pixels
                last_point = j; // probably last white pixel
            }
            else{
                // counting non-white pixels
                not_white++;
            }
            // do we need to keep looking for the last pixel of the ball?
            if (not_white >= (img.width+1)){
                last_found = true;
                ROS_INFO("  last point ball found @ i=%3i", last_point);
                ROS_INFO("  not_white pixels counter = %i (j=%i)", not_white, j); 
                break; // end of ball contour reached; nothing else to look for
            }
        }    
    }
    // When the algorithm reaches this point: 
    // 1) it may not have found any white pixels --> ball_found = false
    // 2) we find the ball, then we work with initial and final values ​​and others
    if (ball_found==true){
        // tries to determine centroid of the ball
        int x1,y1,x2,y2; // auxiliary variables to determine [x, y] for first_point and last_point
        y1 = first_point/img.width; // 0 < y < img.height-1
        // x = rest of division
        x1 = first_point - img.width*y1; // 0 < col < img.step-1
        y2 = last_point/img.width;
        x2 = last_point - img.width*y2;
        x = (int)((x1+x2)/2.0);
        y = (int)((y1+y2)/2.0);
        // ROS_INFO("  first point @ [x,y]=[%i, %i]", x1, y1);
        // ROS_INFO("  last  point @ [x,y]=[%i, %i]", x2, y2);
        ROS_INFO("    centroid ball @ [x,y]=[%i, %i] (%ix%i pixels; step=%i)", x, y, img.width, img.height, img.step);
        ROS_INFO("    ball size = %i", white_area);
        
        // defining robot action
        // angle error ==> ref = img.width/2
        float theta_error;
        float camera_horizontal_center;
        camera_horizontal_center = (float)img.width/2.0;
        // calculating orientation error (theta) in absolute units (pixels)
        theta_error = camera_horizontal_center - (float)x;
        // calculating orientation error (theta) in percentage terms
        theta_error = theta_error/camera_horizontal_center;
        // (float)(img.width/2); // eq. com erro
        // 90^o = M_PI/2
        // rotate a maximum of 90 degrees in 5 seconds
        w = (M_PI/(2.0*5.0))*theta_error; // almost proportional control
        float aux;
        aux = (w*180.0)/M_PI;
        ROS_INFO("      theta_error = %4.2f (0~1) --> w = %4.1f (grados/s)", theta_error, aux);  

        // area of ​​the circle equal to: M_PI*radius^2
        // bigger_area = M_PI*img.width*img.width/4;
        // probably the largest area that can be found when radius=img.width/2
        // comparing size of areas
        float area_error = 0;
        // calculating percentage "error" of the current area found
        if (white_area < bigger_area){
            area_error = (float)(bigger_area - white_area)/(float)(bigger_area);
        }
        v = 1.0*area_error;
        
        // limiting maximum values for linear velocity 
        if (v > max_linear_vel){
            v = max_linear_vel;
        }
        if (v < -max_linear_vel){  // robot probably won't back up
            v = -max_linear_vel;
        }
        
        // ROS_INFO(">    bigger_area = %6i", bigger_area);
        ROS_INFO("      area_error  = %5.2f --> v = %5.3f (m/s)", area_error, v);
    } 

    // Then, identify if this pixel falls in the left, mid, or right side of the image
    // Depending on the white ball position, call the drive_bot function and pass velocities to it
    // Request a stop when there's no white ball seen by the camera
    // or turn over and over looking for the ball
    // if (ball_found){
    // commanding the robot    
    
    drive_robot(v, w); // stops robot           
    
    // }
}

int main(int argc, char** argv)
{
    // Initialize the process_image node and create a handle to it
    ros::init(argc, argv, "process_image");
    ros::NodeHandle n;

    // Define a client service capable of requesting services from command_robot
    client = n.serviceClient<ball_chaser::DriveToTarget>("/ball_chaser/command_robot");

    /* Subscribe to /camera/rgb/image_raw topic to read the image data inside the 
       process_image_callback function */
    ros::Subscriber sub1 = n.subscribe("/camera/rgb/image_raw", 10, process_image_callback);

    ROS_INFO("[process_image]: Ready");

    // Handle ROS communication events
    ros::spin();

    return 0;
}